package com.testSpring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HomeController {
	@RequestMapping(value="/test.do", method = RequestMethod.GET)
	public String test(Model model) {

        System.out.println("ddddd");


        int test1 = 3 + 20;

        model.addAttribute("test1", test1);
		return "test1";
	}
	
}
